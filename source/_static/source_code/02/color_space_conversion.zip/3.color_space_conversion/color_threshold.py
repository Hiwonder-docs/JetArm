#!/usr/bin/env python3
# encoding: utf-8
import cv2
import rospy
import signal
import numpy as np
from sensor_msgs.msg import Image


class color_threshold:
    def __init__(self, name):
        # 初始化节点(initialization node)
        rospy.init_node(name, log_level=rospy.INFO)
        self.name = name
        self.image = None
        self.image_test = None
        self.running = True
        self.image_sub = None
<<<<<<< HEAD
        #设置需要识别的名字和阈值(set the names and thresholds for recognition)
=======
        #设置需要识别的名字和阈值
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
        self.color_threshold = {"blue":[(0,0,0),(255,255,104)],
                                "red":[(0,149,108),(255,255,255)],
                                "green":[(0,0,138),(255,130,255)]}
        #启动程序中断函数(start program interrupt function)
        signal.signal(signal.SIGINT, self.shutdown)
<<<<<<< HEAD
        # 检测图像发布(detect image publish)
=======
        # 检测图像发布
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
        self.image_sub = rospy.Subscriber('/rgbd_cam/color/image_rect_color', Image, self.image_callback)
        rospy.sleep(0.2)
        self.run()
        
    #程序中断函数，用于停止程序(program interrupt function, which is used to stop program)
    def shutdown(self, signum, frame):
        self.running = False
        
    #处理ROS节点数据(processing ROS node data)
    def image_callback(self, ros_image):
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8,
                           buffer=ros_image.data)  # 将ros格式图像消息转化为opencv格式(convert the ros format image information to opencv format)
        #将图像的颜色空间转换成LAB(convert the color space to LAB)
        self.image= cv2.cvtColor(rgb_image, cv2.COLOR_RGB2LAB)
<<<<<<< HEAD
        #设置颜色阈值并进行二值化(set the color threshold and perform binarization)
=======
        #设置颜色阈值并进行二值化
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
        self.image_test = cv2.inRange(self.image,self.color_threshold['blue'][0],self.color_threshold['blue'][1])

    def run(self):
        while self.running:
            if self.image is not None and self.image_test is not None:
                #展示画面(display screen)
                cv2.imshow('TEST', self.image)
                #展示识别到的画面(display recognized screen)
                cv2.imshow('TEST2', self.image_test)
                cv2.waitKey(1)
if __name__ == '__main__':
    color_threshold('color_threshold')
