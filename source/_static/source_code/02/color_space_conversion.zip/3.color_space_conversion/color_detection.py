#!/usr/bin/env python3
# encoding: utf-8
import cv2
import rospy
import signal
import math
import numpy as np
from sensor_msgs.msg import Image

class color_detection:
    def __init__(self, name):
        # 初始化节点(initialization node)
        rospy.init_node(name, log_level=rospy.INFO)
        self.name = name
        self.image = None
        self.image_bgr = None
        self.image_test = None
        self.running = True
<<<<<<< HEAD
        #设置需要识别的名字和阈值(set the names and thresholds for recognition)
=======
        #设置需要识别的名字和阈值
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
        self.color_threshold = {"blue":[(0,0,0),(255,255,104)],
                                "red":[(0,149,108),(255,255,255)],
                                "green":[(0,0,138),(255,130,255)]}
        #启动程序中断函数(start program interrupt function)
        signal.signal(signal.SIGINT, self.shutdown)

<<<<<<< HEAD
        # 检测图像发布(detect image publish)
=======
        # 检测图像发布
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
        self.image_sub = rospy.Subscriber('/rgbd_cam/color/image_rect_color', Image, self.image_callback)
        rospy.sleep(0.2)
        self.run()
        
    #程序中断函数，用于停止程序(program interrupt function, which is used to stop program)
    def shutdown(self, signum, frame):
        self.running = False
        
    #处理ROS节点数据(processing ROS node data)
    def image_callback(self, ros_image):
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8,
                           buffer=ros_image.data)  # 将ros格式图像消息转化为opencv格式(convert the ros format image information to opencv format)
        #RGB转LAB(convert RGB to LAB)
        self.image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2LAB)
        #RGB转BGR(convert RGB to BGR)
        self.image_bgr = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR) 
    
    def erode_and_dilate(self, binary, kernel=3):
        # 腐蚀膨胀(corrosion and dilation)
        element = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel, kernel))
        eroded = cv2.erode(binary, element)  # 腐蚀(corrosion)
        dilated = cv2.dilate(eroded, element)  # 膨胀(dilation)
        return dilated

    #颜色识别函数(color recognition function)
    def color_detection(self,color):
        #将颜色空间转换为LAB(convert the color space to LAB)
        self.image_test = cv2.GaussianBlur(self.image_bgr, (3, 3), 3)
        self.image_test = cv2.cvtColor(self.image_test, cv2.COLOR_BGR2LAB)
        #将颜色阈值填入，并输出识别后的二值化图像(fill in the color thresholds and output the binary image after recognition)
        self.image_test = cv2.inRange(self.image_test,
                                       self.color_threshold[color][0],
                                       self.color_threshold[color][1])
        self.image_test = self.erode_and_dilate(self.image_test)
        # 找出所有轮廓(find out all contours)
        contours = cv2.findContours(self.image_test, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)[-2]  
        # 遍历轮廓(iterate through contour)
        c = max(contours, key = cv2.contourArea)
        area = math.fabs(cv2.contourArea(c))  
        if area >= 2000:
            print("检测到",color)

    def run(self):
        while self.running:
            try:
                if self.image is not None:
                    #设置所需识别的所有颜色及其阈值(set the color and thresholds for recognition)
                    self.color_detection("red")
                if self.image_bgr is not None and self.image_test is not None:
                    #展示识别效果(display recognition effect)
                    cv2.imshow('RGB', self.image_bgr)
                    cv2.imshow('color_detection', self.image_test)
                    cv2.waitKey(1)

            except Exception as e:
                print("未检测到所需识别的颜色，请将色块放置到相机视野内。")
if __name__ == '__main__':
    color_detection('color_detection')
