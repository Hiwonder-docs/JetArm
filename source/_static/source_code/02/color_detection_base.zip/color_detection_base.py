#!/usr/bin/env python3
# encoding: utf-8
import cv2
import math
import numpy as np

class color_detection:
    def __init__(self):
        self.image = None
        self.image_rgb = None
        self.image_test = None
        #设置图像宽高(set the width and height of the image)
        self.size = {"height":240,"width":320}
        #设置颜色阈值(set color threshold)
        self.color_threshold = {"blue":[(0,0,0),(255,255,104)],
                                "red":[(0,149,108),(255,255,255)],
                                "green":[(0,0,138),(255,130,255)]}


    def erode_and_dilate(self, binary, kernel=3):
        # 腐蚀膨胀(corrosion and dilation)
        element = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel, kernel))
        eroded = cv2.erode(binary, element)  # 腐蚀(corrosion)
        dilated = cv2.dilate(eroded, element)  # 膨胀(dilation)

        return dilated
        
    # 颜色识别函数(color recognition function)
    def color_detection(self,color,image_bgr):
         # 得到图像的宽高(get the width and height of the image)
         img_h, img_w = image_bgr.shape[:2]
         # 高斯模糊(Gaussian blur)
         self.image_test = cv2.GaussianBlur(image_bgr, (3, 3), 3)
         # 转换颜色空间(convert color space)
         self.image_test = cv2.cvtColor(self.image_test, cv2.COLOR_BGR2LAB)
         # 根据阈值识别颜色(recognize color based on threshold)
         self.image_test = cv2.inRange(self.image_test,
                                       self.color_threshold[color][0],
                                       self.color_threshold[color][1])
         # 腐蚀膨胀(corrosion and dilation)
         self.image_test = self.erode_and_dilate(self.image_test)

             
         return self.image_test 

if __name__ == '__main__':
    color_detection()
