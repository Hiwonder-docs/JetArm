#!/usr/bin/env python3
# encoding: utf-8
import cv2
import math
import sys
import rospy
import signal
import numpy as np
from sensor_msgs.msg import Image
sys.path.append('/home/hiwonder/jetarm/src/jetarm_example/src/Simple_library')
import color_detection_base

class attitude_calculation:
    def __init__(self, name):
        # 初始化节点(initialization node)
        rospy.init_node(name, log_level=rospy.INFO)
        self.name = name
        self.image = None
        self.image_rgb = None
        self.image_test = None
        self.running = True
        self.color = rospy.get_param('~color', 'red')
        # 初始化颜色识别类(initialize color recognition class)
        self.color_detection = color_detection_base.color_detection()
        # 启动程序中断函数(start program interrupt function)
        signal.signal(signal.SIGINT, self.shutdown)
<<<<<<< HEAD
        # 订阅图像发布节点(subscribe image publish node)
=======
        # 订阅图像发布节点
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
        self.image_sub = rospy.Subscriber('/rgbd_cam/color/image_rect_color', Image, self.image_callback)
        rospy.sleep(0.2)
        self.run()
    #程序中断函数，用于停止程序(program interrupt function, which is used to stop program)
    def shutdown(self, signum, frame):
        self.running = False
        
    #处理ROS节点数据(process ROS node data)
    def image_callback(self, ros_image):
        # 将ros格式图像消息转化为opencv格式(convert the ros format image information to opencv format)
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8,
                           buffer=ros_image.data)  
        # 将图像颜色空间转换成LAB(convert the color space to LAB)
        self.image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2LAB)
        # 将图像颜色空间转换成BGR(convert the color space to RGB)
        self.image_bgr = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)

    def run(self):
        while self.running:
            try:
                if self.image is not None and self.image_bgr is not None : 
<<<<<<< HEAD
                    # 启动颜色识别并且将识别后的图像数据读取(initiate color recognition and read the data of the recognized image)
=======
                    # 启动颜色识别并且将识别后的图像数据读取
>>>>>>> 7d22c354eb0202c6087f482461a5d8eeacd09e51
                    self.image_test = self.color_detection.color_detection(self.color,self.image_bgr)
                    # 计算识别到的轮廓(calculate recognized contour)
                    contours = cv2.findContours(self.image_test, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)[-2]  # 找出所有轮廓(find out all contours)
                    # 找出最大轮廓(find out the largest contour)
                    c = max(contours, key = cv2.contourArea)
                    # 计算轮廓面积(calculate contour area)
                    area = math.fabs(cv2.contourArea(c))  
                    # 根据轮廓大小判断是否进行下一步处理(determine whether to proceed to the next step based on the size of the contour)
                    rect = cv2.minAreaRect(c)  # 获取最小外接矩形(get the minimum bounding rectangle)
                    yaw = int(round(rect[2]))  # 矩形角度(rectangle angle)
                    print("物体姿态:","yaw:",yaw)
                    # 展示(display)
                    cv2.imshow('BGR', self.image_bgr)
                    cv2.imshow('color_detection', self.image_test)
                    cv2.waitKey(1)
            except Exception as e:
                 print("未检测到所需识别的颜色，请将色块放置到相机视野内。")
if __name__ == '__main__':
    attitude_calculation('attitude_calculation')
